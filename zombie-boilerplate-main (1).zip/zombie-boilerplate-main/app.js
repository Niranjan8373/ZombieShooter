const button = document.getElementById("button");

button.onclick = () => {
  location.href = "./game.html";
};